import argparse
import io
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

SOURCE_URL = "https://edvyro.in/datasets/customer_churn_sample.csv"
OUT = Path("outputs")


def load_data(input_path: str | None) -> pd.DataFrame:
    if input_path and Path(input_path).exists():
        return pd.read_csv(input_path)
    try:
        with urllib.request.urlopen(SOURCE_URL, timeout=20) as response:
            raw = response.read()
        return pd.read_csv(io.BytesIO(raw))
    except Exception as exc:
        raise SystemExit(
            "Could not download the task CSV. Download it from "
            f"{SOURCE_URL}, save it locally, and run with --input path/to/file.csv.\n"
            f"Download error: {exc}"
        )


def main():
    parser = argparse.ArgumentParser(description="Customer churn data quality audit and EDA")
    parser.add_argument("--input", help="Path to the task CSV (optional if download works)")
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    raw = load_data(args.input)
    df = raw.copy()
    audit = []
    audit.append("CUSTOMER CHURN DATA QUALITY AUDIT")
    audit.append("=" * 40)
    audit.append(f"Raw rows: {len(df)}")
    audit.append(f"Raw columns: {len(df.columns)}")
    audit.append("\nColumn profile:")
    profile = pd.DataFrame({
        "column": df.columns,
        "dtype_before": [str(df[c].dtype) for c in df.columns],
        "missing_count": [int(df[c].isna().sum()) for c in df.columns],
        "missing_percent": [round(float(df[c].isna().mean() * 100), 2) for c in df.columns],
        "distinct_values": [int(df[c].nunique(dropna=True)) for c in df.columns],
    })
    audit.append(profile.to_string(index=False))

    exact_duplicates = int(df.duplicated().sum())
    audit.append(f"\nExact duplicate rows: {exact_duplicates}")
    id_cols = [c for c in df.columns if c.strip().lower() in {
        "customerid", "customer_id", "customer id", "id"
    }]
    for col in id_cols:
        audit.append(f"Duplicate non-null values in ID column '{col}': {int(df[col].dropna().duplicated().sum())}")

    # Normalize text whitespace and standardize empty strings to missing.
    for col in df.select_dtypes(include=["object", "string"]).columns:
        df[col] = df[col].astype("string").str.strip()
        df[col] = df[col].replace("", pd.NA)

    # Convert numeric-looking object columns only if at least 90% of non-null values parse.
    conversions = []
    for col in df.select_dtypes(include=["object", "string"]).columns:
        nonmissing = df[col].dropna()
        if len(nonmissing) == 0:
            continue
        parsed = pd.to_numeric(nonmissing, errors="coerce")
        if parsed.notna().mean() >= 0.90:
            before_bad = int(parsed.isna().sum())
            df[col] = pd.to_numeric(df[col], errors="coerce")
            conversions.append(f"{col}: converted to numeric; non-parsing values among non-missing before conversion: {before_bad}")

    # Drop exact duplicate rows only; retain duplicate IDs for review.
    before = len(df)
    df = df.drop_duplicates().copy()
    removed = before - len(df)
    audit.append(f"Exact duplicate rows removed: {removed}")

    # IQR flags on numeric columns; retain flagged records.
    numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
    outlier_rows = []
    for col in numeric_cols:
        s = df[col].dropna()
        if len(s) < 4:
            continue
        q1, q3 = s.quantile([0.25, 0.75])
        iqr = q3 - q1
        low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        count = int(((df[col] < low) | (df[col] > high)).sum())
        outlier_rows.append({"column": col, "q1": q1, "q3": q3, "iqr_lower_bound": low,
                             "iqr_upper_bound": high, "outlier_count": count})
    outliers = pd.DataFrame(outlier_rows)
    if not outliers.empty:
        outliers.to_csv(OUT / "outlier_flags.csv", index=False)

    # Impute missing values in analysis copy: numeric median, categorical Unknown.
    imputation_notes = []
    for col in df.columns:
        n_missing = int(df[col].isna().sum())
        if n_missing == 0:
            continue
        if pd.api.types.is_numeric_dtype(df[col]):
            med = df[col].median()
            if pd.notna(med):
                df[col] = df[col].fillna(med)
                imputation_notes.append(f"{col}: filled {n_missing} missing numeric values with median {med}.")
        else:
            df[col] = df[col].fillna("Unknown")
            imputation_notes.append(f"{col}: filled {n_missing} missing categorical/text values with 'Unknown'.")

    # Summary stats and target/churn distribution.
    stats = df.describe(include="all").transpose()
    stats.to_csv(OUT / "summary_statistics.csv")
    profile.to_csv(OUT / "column_profile.csv", index=False)
    df.to_csv(OUT / "cleaned_customer_churn.csv", index=False)

    # Detect likely churn target field by name.
    target_candidates = [c for c in df.columns if c.strip().lower() in {
        "churn", "exited", "is_churn", "churned", "customer_churn"
    }]
    if target_candidates:
        target = target_candidates[0]
        audit.append(f"\nDetected churn target column: {target}")
        audit.append("Target value counts:")
        audit.append(df[target].astype("string").value_counts(dropna=False).to_string())
        # Binary numeric 0/1 or yes/no labels only.
        normalized = df[target].astype("string").str.strip().str.lower()
        yes_values = {"yes", "true", "1", "churned", "exited"}
        no_values = {"no", "false", "0", "active", "retained", "not churned"}
        mapped = normalized.map(lambda x: 1 if x in yes_values else (0 if x in no_values else np.nan))
        if mapped.notna().any():
            audit.append(f"Interpretable churn rate: {mapped.mean() * 100:.2f}% (among interpretable target values)")
        else:
            audit.append("Churn rate not calculated: target values are not recognized as binary churn labels.")
        plt.figure()
        df[target].astype("string").value_counts(dropna=False).plot(kind="bar")
        plt.title(f"Distribution of {target}")
        plt.xlabel(target)
        plt.ylabel("Customer count")
        plt.tight_layout()
        plt.savefig(OUT / "churn_distribution.png", dpi=150)
        plt.close()
    else:
        audit.append("\nNo conventional churn target column name was detected.")
        audit.append("Inspect the column profile and update target detection if the dataset uses a different label.")

    # Numeric histograms and boxplots.
    for col in numeric_cols[:8]:
        values = df[col].dropna()
        if values.empty:
            continue
        plt.figure()
        values.plot(kind="hist", bins=20)
        plt.title(f"Distribution of {col}")
        plt.xlabel(col)
        plt.ylabel("Frequency")
        plt.tight_layout()
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in col)
        plt.savefig(OUT / f"hist_{safe}.png", dpi=150)
        plt.close()
        plt.figure()
        values.plot(kind="box")
        plt.title(f"Outlier review: {col}")
        plt.ylabel(col)
        plt.tight_layout()
        plt.savefig(OUT / f"box_{safe}.png", dpi=150)
        plt.close()

    # Validation checks.
    validation = {
        "no_exact_duplicate_rows": not df.duplicated().any(),
        "no_blank_column_names": all(str(c).strip() for c in df.columns),
        "no_missing_values_after_imputation": not df.isna().any().any(),
        "row_count_after_cleaning_not_greater_than_raw": len(df) <= len(raw),
    }
    audit.append("\nCleaning notes:")
    audit.extend(conversions or ["No numeric-looking text columns required conversion."])
    audit.extend(imputation_notes or ["No missing values required imputation."])
    audit.append("\nValidation checks:")
    for name, passed in validation.items():
        audit.append(f"{name}: {'PASS' if passed else 'REVIEW'}")
    audit.append(f"\nCleaned rows: {len(df)}")
    audit.append(f"Cleaned columns: {len(df.columns)}")
    audit.append("\nInterpretation reminder: IQR outliers are flags, not automatic errors. Check business context before removing them.")
    (OUT / "quality_audit.txt").write_text("\n".join(audit), encoding="utf-8")
    print("Analysis complete. Review the outputs/ folder.")
    print(f"Rows: {len(raw)} raw -> {len(df)} cleaned")
    print(f"Exact duplicate rows removed: {removed}")
    print("Open outputs/quality_audit.txt and outputs/summary_statistics.csv first.")


if __name__ == "__main__":
    main()
