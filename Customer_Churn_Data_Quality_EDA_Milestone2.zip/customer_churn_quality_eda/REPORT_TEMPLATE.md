# Milestone 2 Report: Data Quality and Exploratory Analysis

## 1. Objective
The objective is to audit the customer churn dataset, clean obvious data-quality issues using documented assumptions, validate the resulting table, and inspect initial distributions relevant to customer retention.

## 2. Data source
Dataset supplied in the task instructions: https://edvyro.in/datasets/customer_churn_sample.csv

## 3. Method
The repeatable analysis script profiles columns, types, missing values, distinct values, exact duplicate rows, duplicate customer IDs (when present), numeric outliers using the 1.5 × IQR rule, and descriptive statistics. It trims text whitespace, converts numeric-looking text only when conversion is sufficiently reliable, removes exact duplicate rows, imputes missing numeric values with the median and missing categorical values with `Unknown` for exploratory analysis, and writes validation results.

## 4. Results
Run `python src/analyze_churn.py --input customer_churn_sample.csv` to generate actual dataset-specific results. Copy the measured values from:
- `outputs/quality_audit.txt`
- `outputs/column_profile.csv`
- `outputs/summary_statistics.csv`
- `outputs/outlier_flags.csv` (if numeric columns qualify)
- charts in `outputs/`

Do not submit this section with placeholders. Report the real row count, column count, duplicate count, missing-value findings, outlier flags, and churn distribution from the generated outputs.

## 5. Initial patterns to inspect
- Overall proportion of churned versus retained customers.
- Whether churn differs by contract type, tenure, service plan, payment method, or monthly charges (depending on available columns).
- Skewed numerical variables and potential outliers.
- Whether missingness is concentrated in particular columns.

## 6. Quality decisions and limitations
Exact duplicate rows are removed; duplicate IDs are reported rather than automatically deleted. IQR outliers are flagged but retained unless the source definition confirms an error. Median/Unknown imputation is used only to support exploratory summaries and must be reconsidered before predictive modeling. The dataset’s actual field definitions should be checked before interpreting correlations as causes.

## 7. Reproducibility
The project includes a script, requirements file, cleaning-decision log, and this report template. Run the script against the original task CSV to regenerate the cleaned dataset, statistics, audit, and charts. Keep the raw source file unchanged.
