# Customer Churn — Data Quality & Exploratory Analysis
Milestone 2 of 3 | Beginner-friendly data analytics project

## Goal
Audit the supplied customer churn CSV, document quality decisions, create a cleaned dataset, and explore initial churn patterns.

## Files
- `src/analyze_churn.py` — repeatable audit, cleaning, statistics, and chart generation.
- `requirements.txt` — Python dependencies.
- `outputs/` — generated reports, cleaned CSV, and charts will be saved here after running the script.
- `QUALITY_DECISIONS.md` — cleaning assumptions and validation rules.

## Run it
1. Install Python 3.10+.
2. Download the CSV from the task page: https://edvyro.in/datasets/customer_churn_sample.csv
3. Save it in this folder as `customer_churn_sample.csv`.
4. Open a terminal in this folder and run:
   ```bash
   pip install -r requirements.txt
   python src/analyze_churn.py --input customer_churn_sample.csv
   ```
5. Review `outputs/quality_audit.txt`, `outputs/summary_statistics.csv`, `outputs/cleaned_customer_churn.csv`, and the PNG charts.

The script also attempts to download the official task CSV if no local input is supplied. If the download fails, use step 2–3.

## Important
The script calculates results from the actual CSV when run. No sample counts or churn rates are pre-filled or invented. Review the generated audit and charts before submitting.
