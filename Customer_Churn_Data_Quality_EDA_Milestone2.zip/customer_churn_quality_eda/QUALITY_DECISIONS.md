# Data quality decisions and assumptions

1. **Keep a raw copy:** the source CSV is read but never overwritten.
2. **Column profile:** report row/column counts, column names, inferred data types, missing values, and distinct values.
3. **Duplicates:** identify exact duplicate rows and remove exact duplicates. If a customer ID column exists, report duplicate IDs separately; do not silently remove them because repeated records may have meaning.
4. **Missing values:** report missing counts and percentages for every column. For numeric fields, fill missing values with the median only in the cleaned analysis copy; for categorical fields, use `Unknown`. If a target/churn label is missing, exclude those rows from churn-rate calculations and record the count.
5. **Types and text:** trim leading/trailing whitespace from text columns. Convert numeric-looking fields only when conversion is safe; record failed conversions.
6. **Outliers:** use the 1.5 × IQR rule for numeric columns as a flag, not an automatic deletion rule. Extreme but plausible customer charges or tenure values are retained pending domain review.
7. **Validation:** check that the cleaned file has no exact duplicate rows, no blank column names, and no unhandled missing values in columns that were imputed. If a churn/target column is detected, report its values and churn rate only when its values can be interpreted safely.
8. **Reproducibility:** the script writes a text audit, a statistics CSV, cleaned CSV, and charts into `outputs/`. Re-run the same command to regenerate outputs.

## Limitations
- Dataset-specific decisions should be reviewed after examining the actual column names and business definitions.
- Median/mode-style filling is for exploratory analysis only. For predictive modeling, decide on imputation using training data only to avoid data leakage.
- IQR flags do not prove a record is erroneous.
